/* DASHBOARD JAVASCRIPT */

document.addEventListener("DOMContentLoaded", function () {

    console.log("Dashboard loaded");

});


function refreshDashboard() {

    location.reload();

}


function showRevenueDetails() {

    showNotification(
        "Revenue details opened."
    );

}


function dashboardNotification(message) {

    showNotification(message);

}