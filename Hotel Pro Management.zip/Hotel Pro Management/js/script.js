/* =========================================================
   HOTELPRO MANAGEMENT SUITE
   MAIN JAVASCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    setActiveSidebar();

    setupModalClicks();

    setupTableSearch();

});


/* =========================================================
   ACTIVE SIDEBAR
   ========================================================= */

function setActiveSidebar() {

    const currentPage =
        window.location.pathname.split("/").pop();

    const links =
        document.querySelectorAll(".sidebar-menu a");

    links.forEach(function (link) {

        const page =
            link.getAttribute("href");

        if (page === currentPage) {

            link.classList.add("active");

        }

    });

}


/* =========================================================
   MODAL
   ========================================================= */

function setupModalClicks() {

    const modals =
        document.querySelectorAll(".modal");

    modals.forEach(function (modal) {

        modal.addEventListener(
            "click",
            function (event) {

                if (event.target === modal) {

                    modal.classList.remove("show");

                }

            }
        );

    });

}


/* =========================================================
   NOTIFICATION
   ========================================================= */

function showNotification(message) {

    const notification =
        document.createElement("div");

    notification.className =
        "hotel-notification";

    notification.innerHTML = `
        <i class="fa-solid fa-circle-check"></i>
        <span>${message}</span>
    `;

    document.body.appendChild(notification);


    setTimeout(function () {

        notification.classList.add(
            "notification-show"
        );

    }, 50);


    setTimeout(function () {

        notification.classList.remove(
            "notification-show"
        );

        setTimeout(function () {

            notification.remove();

        }, 300);

    }, 3000);

}


/* =========================================================
   CURRENCY
   ========================================================= */

function formatCurrency(amount) {

    return new Intl.NumberFormat(
        "en-IN",
        {
            style: "currency",
            currency: "INR",
            maximumFractionDigits: 0
        }
    ).format(amount);

}


/* =========================================================
   DATE FORMAT
   ========================================================= */

function formatDate(date) {

    return new Date(date).toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


/* =========================================================
   CONFIRM ACTION
   ========================================================= */

function confirmAction(message) {

    return confirm(message);

}


/* =========================================================
   PRINT
   ========================================================= */

function printPage() {

    window.print();

}


/* =========================================================
   LOGOUT
   ========================================================= */

function logout() {

    const result =
        confirm(
            "Are you sure you want to logout?"
        );

    if (result) {

        window.location.href =
            "index.html";

    }

}


/* =========================================================
   GENERIC TABLE SEARCH
   ========================================================= */

function setupTableSearch() {

    const searchInputs =
        document.querySelectorAll(
            "[data-table-search]"
        );

    searchInputs.forEach(function (input) {

        input.addEventListener(
            "keyup",
            function () {

                const tableId =
                    input.getAttribute(
                        "data-table-search"
                    );

                const table =
                    document.getElementById(
                        tableId
                    );

                if (!table) return;

                const search =
                    input.value.toLowerCase();

                const rows =
                    table.querySelectorAll(
                        "tbody tr"
                    );

                rows.forEach(function (row) {

                    const text =
                        row.innerText.toLowerCase();

                    row.style.display =
                        text.includes(search)
                            ? ""
                            : "none";

                });

            }
        );

    });

}


/* =========================================================
   DELETE CONFIRMATION
   ========================================================= */

function deleteItem(itemName) {

    const result =
        confirm(
            "Are you sure you want to delete " +
            itemName +
            "?"
        );

    if (result) {

        showNotification(
            itemName +
            " deleted successfully."
        );

    }

}


/* =========================================================
   SAVE
   ========================================================= */

function saveData(message) {

    showNotification(
        message || "Changes saved successfully."
    );

}


/* =========================================================
   PAGE REFRESH
   ========================================================= */

function refreshPage() {

    location.reload();

}


/* =========================================================
   MOBILE SIDEBAR
   ========================================================= */

function toggleSidebar() {

    const sidebar =
        document.querySelector(".sidebar");

    if (!sidebar) return;

    sidebar.classList.toggle(
        "sidebar-open"
    );

}