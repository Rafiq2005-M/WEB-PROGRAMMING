/* RESERVATIONS JAVASCRIPT */

function searchReservations() {

    const input =
        document.getElementById("reservationSearch");

    const rows =
        document.querySelectorAll(
            "#reservationTable tbody tr"
        );

    if (!input) return;

    const search =
        input.value.toLowerCase();

    rows.forEach(function (row) {

        row.style.display =
            row.innerText
                .toLowerCase()
                .includes(search)
                ? ""
                : "none";

    });

}


function addReservation() {

    showNotification(
        "New reservation added successfully."
    );

}


function cancelReservation(id) {

    if (
        confirm(
            "Cancel reservation " +
            id +
            "?"
        )
    ) {

        showNotification(
            "Reservation cancelled."
        );

    }

}


function viewReservation(id) {

    showNotification(
        "Opening reservation " + id
    );

}